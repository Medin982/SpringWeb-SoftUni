package com.example.spotifyplaylistapplication.models.enums;

public enum StyleType {
    POP, ROCK, JAZZ
}
