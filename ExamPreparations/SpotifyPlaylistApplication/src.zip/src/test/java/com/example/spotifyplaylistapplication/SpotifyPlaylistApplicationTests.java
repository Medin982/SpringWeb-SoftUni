package com.example.spotifyplaylistapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyPlaylistApplicationTests {

    @Test
    void contextLoads() {
    }

}
